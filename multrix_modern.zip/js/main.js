// main.js - animations and interactions (uses GSAP + ScrollTrigger + VanillaTilt)
document.addEventListener('DOMContentLoaded', function(){

  // Mobile nav
  const navToggle = document.getElementById('navToggle');
  navToggle && navToggle.addEventListener('click', ()=> {
    const nav = document.querySelector('.nav');
    if(nav.style.display === 'flex') nav.style.display = '';
    else nav.style.display = 'flex';
  });

  // Vanilla Tilt for card micro-interactions (auto init on elements with class .tilt)
  if(window.VanillaTilt){
    document.querySelectorAll('.tilt').forEach(el => {
      VanillaTilt.init(el, { max: 12, speed: 400, glare: true, "max-glare": 0.15 });
    });
  }

  // GSAP animations
  try{
    gsap.registerPlugin(ScrollTrigger);

    // Hero intro
    gsap.from(".hero-title", { y: 30, opacity:0, duration:1, ease:"power3.out" });
    gsap.from(".hero-sub", { y: 18, opacity:0, duration:.9, delay:.15, ease:"power3.out" });
    gsap.from(".hero-ctas a", { y: 12, opacity:0, stagger:.08, duration:.7, delay:.28 });

    // Reveal on scroll for sections
    gsap.utils.toArray('.section').forEach(section => {
      gsap.from(section.querySelectorAll('h2, p, .card, .work-card, .about-stats, .contact-form'), {
        y: 20, opacity:0, duration:0.8, stagger:0.08,
        scrollTrigger: { trigger: section, start: "top 80%" }
      });
    });

    // Parallax subtle background movement
    gsap.to('.hero__bg', { yPercent: -8, ease:"none", scrollTrigger: { scrub: 0.6 } });

  }catch(e){ console.warn('GSAP not available', e) }

  // Accessibility: ensure links are focusable
  document.querySelectorAll('a,button,input,textarea').forEach(el => el.setAttribute('tabindex','0'));
});
